# STATIC WEBSITE   http://lirim-super-bucket-v1.s3-website.us-east-2.amazonaws.com   
