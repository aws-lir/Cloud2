#Command to connect sudo mysql -h terraform-20201225184212782100000001.chpyezhlhve7.us-east-1.rds.amazonaws.com  -P 3306 -u testuser -p -e 'SHOW DATABASES' 
